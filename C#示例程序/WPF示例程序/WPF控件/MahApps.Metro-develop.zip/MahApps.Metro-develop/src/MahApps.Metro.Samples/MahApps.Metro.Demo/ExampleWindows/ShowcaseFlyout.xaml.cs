﻿namespace MetroDemo.ExampleWindows
{
    using MahApps.Metro.Controls;

    public sealed partial class ShowcaseFlyout : Flyout
    {
        public ShowcaseFlyout()
        {
            this.InitializeComponent();
        }
    }
}
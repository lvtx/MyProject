﻿using System.Windows.Controls;

namespace MetroDemo.ExampleViews
{
    /// <summary>
    /// Interaction logic for DataGridExamples.xaml
    /// </summary>
    public partial class DataGridExamples : UserControl
    {
        public DataGridExamples()
        {
            InitializeComponent();
        }
    }
}

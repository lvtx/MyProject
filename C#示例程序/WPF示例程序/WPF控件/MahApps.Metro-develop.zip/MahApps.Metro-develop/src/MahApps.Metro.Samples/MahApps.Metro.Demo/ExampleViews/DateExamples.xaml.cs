﻿using System.Windows.Controls;

namespace MetroDemo.ExampleViews
{
    /// <summary>
    /// Interaction logic for DateExamples.xaml
    /// </summary>
    public partial class DateExamples : UserControl
    {
        public DateExamples()
        {
            InitializeComponent();
        }
    }
}

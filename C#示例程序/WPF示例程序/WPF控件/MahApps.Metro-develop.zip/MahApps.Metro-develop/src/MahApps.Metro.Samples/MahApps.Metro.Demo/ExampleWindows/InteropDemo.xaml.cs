﻿namespace MetroDemo.ExampleWindows
{
    public partial class InteropDemo
    {
        public InteropDemo()
        {
            InitializeComponent();
        }
    }
}

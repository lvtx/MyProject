﻿using System.Windows.Controls;

namespace MetroDemo.Navigation
{
    /// <summary>
    /// Interaction logic for InterestingPage.xaml
    /// </summary>
    public partial class InterestingPage : Page
    {
        public InterestingPage()
        {
            InitializeComponent();
        }
    }
}

﻿using System.Windows.Controls;

namespace MetroDemo.ExampleViews
{
    /// <summary>
    /// Interaction logic for CustomDialogContent.xaml
    /// </summary>
    public partial class CustomDialogExample : UserControl
    {
        public CustomDialogExample()
        {
            InitializeComponent();
        }
    }
}

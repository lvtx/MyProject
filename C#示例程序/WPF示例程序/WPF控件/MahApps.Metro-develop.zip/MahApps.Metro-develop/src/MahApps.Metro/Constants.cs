﻿namespace MahApps.Metro
{
    internal class AppName
    {
        public const string MahApps = "MahApps.Metro";
    }
}
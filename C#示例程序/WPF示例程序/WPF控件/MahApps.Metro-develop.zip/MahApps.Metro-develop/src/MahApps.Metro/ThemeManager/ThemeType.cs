﻿namespace MahApps.Metro
{
    /// <summary>
    /// An Enum representing the theme type.
    /// </summary>
    public enum ThemeType
    {
        Unknown,
        Light,
        Dark
    }
}
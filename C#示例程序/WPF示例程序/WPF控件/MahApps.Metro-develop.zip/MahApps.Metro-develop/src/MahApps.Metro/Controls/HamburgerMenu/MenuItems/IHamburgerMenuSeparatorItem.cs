﻿namespace MahApps.Metro.Controls
{
    public interface IHamburgerMenuSeparatorItem
    {
    }
}
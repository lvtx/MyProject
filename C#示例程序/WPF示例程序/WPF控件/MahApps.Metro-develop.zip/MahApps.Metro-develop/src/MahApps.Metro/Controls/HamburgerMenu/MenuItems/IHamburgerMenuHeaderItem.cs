﻿namespace MahApps.Metro.Controls
{
    public interface IHamburgerMenuHeaderItem
    {
        /// <summary>
        /// Gets or sets a value that specifies label to display.
        /// </summary>
        string Label { get; set; }
    }
}
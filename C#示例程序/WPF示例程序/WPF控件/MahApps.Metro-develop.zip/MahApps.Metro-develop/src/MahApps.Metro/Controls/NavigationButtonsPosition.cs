﻿namespace MahApps.Metro.Controls
{
    public enum NavigationButtonsPosition
    {
        Inside,
        Outside
    }
}

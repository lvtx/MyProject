﻿using System.Windows;

namespace MahApps.Metro.Tests
{
    public partial class TestApp : Application
    {
    }
}
﻿using MahApps.Metro.Controls;

namespace MahApps.Metro.Tests
{
    public partial class HiddenMinMaxCloseButtonsWindow : MetroWindow
    {
        public HiddenMinMaxCloseButtonsWindow()
        {
            InitializeComponent();
        }
    }
}

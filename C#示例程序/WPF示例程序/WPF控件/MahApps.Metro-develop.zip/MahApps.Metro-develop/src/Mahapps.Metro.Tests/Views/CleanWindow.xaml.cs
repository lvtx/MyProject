﻿using MahApps.Metro.Controls;

namespace MahApps.Metro.Tests
{
    public partial class CleanWindow : MetroWindow
    {
        public CleanWindow()
        {
            InitializeComponent();
        }
    }
}

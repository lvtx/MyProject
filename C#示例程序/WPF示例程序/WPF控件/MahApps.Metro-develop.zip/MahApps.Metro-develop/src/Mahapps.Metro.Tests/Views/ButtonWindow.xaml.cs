﻿using MahApps.Metro.Controls;

namespace MahApps.Metro.Tests
{
    public partial class ButtonWindow : MetroWindow
    {
        public ButtonWindow()
        {
            InitializeComponent();
        }
    }
}

﻿using MahApps.Metro.Controls;

namespace MahApps.Metro.Tests
{
    public partial class TextBoxHelperTestWindow : MetroWindow
    {
        public TextBoxHelperTestWindow()
        {
            InitializeComponent();
        }
    }
}

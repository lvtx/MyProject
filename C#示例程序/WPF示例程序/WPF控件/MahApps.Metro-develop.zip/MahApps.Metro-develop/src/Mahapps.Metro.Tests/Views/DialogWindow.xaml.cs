﻿using MahApps.Metro.Controls;

namespace MahApps.Metro.Tests
{
    public partial class DialogWindow : MetroWindow
    {
        public DialogWindow()
        {
            InitializeComponent();
        }
    }
}

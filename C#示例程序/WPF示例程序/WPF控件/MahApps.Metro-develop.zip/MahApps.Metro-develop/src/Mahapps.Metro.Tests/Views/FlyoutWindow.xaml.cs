﻿using MahApps.Metro.Controls;

namespace MahApps.Metro.Tests
{
    public partial class FlyoutWindow : MetroWindow
    {
        public FlyoutWindow()
        {
            InitializeComponent();
        }
    }
}

﻿using MahApps.Metro.Controls;

namespace MahApps.Metro.Tests
{
    public partial class NumericUpDownWindow : MetroWindow
    {
        public NumericUpDownWindow()
        {
            InitializeComponent();
        }
    }
}

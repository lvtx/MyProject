﻿using MahApps.Metro.Controls;

namespace MahApps.Metro.Tests
{
    public partial class DateAndTimePickerWindow : MetroWindow
    {
        public DateAndTimePickerWindow()
        {
            InitializeComponent();
        }
    }
}
